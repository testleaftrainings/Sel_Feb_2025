package week3.day2;

public class Ford extends Car {

	public static void main(String[] args) {
		Ford fordOptions=new Ford();
		fordOptions.advancedBrake();
		fordOptions.applyBrake();

	}

}

//Ford extends Car extends Vehicle