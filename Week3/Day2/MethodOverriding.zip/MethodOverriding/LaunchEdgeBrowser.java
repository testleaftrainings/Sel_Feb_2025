package week3.day2;

import org.openqa.selenium.edge.EdgeDriver;

public class LaunchEdgeBrowser {
	
	public void launch() {
		System.out.println("Edge");

	}
	
	public static void main(String[] args) {
		LaunchEdgeBrowser browser=new LaunchEdgeBrowser();
		browser.launch();

	}

}
