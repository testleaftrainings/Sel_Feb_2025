package week3.day2;

public class ParentClass {
	
	
	public void parentBehaviour() {
		System.out.println("Parent Character");

	}
	
	public static void main(String[] args) {
		ParentClass parent=new ParentClass();
		parent.parentBehaviour();

	}

}
