package base;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.DataProvider;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import utils.ReadExcel;



public class BaseClass extends AbstractTestNGCucumberTests{
	
	//public ChromeDriver driver;
	private static final ThreadLocal<ChromeDriver> cDriver=new ThreadLocal<ChromeDriver>();
	public static String filename;
	public static ExtentReports extent;
	public static String testauthor,testcategory,testname,testdescription;
	public static ExtentTest test;
	
	public void setDriver() {
		cDriver.set(new ChromeDriver());

	}
	
	public ChromeDriver getDriver() {
		ChromeDriver chrome = cDriver.get();
return chrome;
	}
	
	@BeforeSuite
	public void startReport() {
		        //Step1: Set the path
				ExtentHtmlReporter reporter=new ExtentHtmlReporter("./reports/result.html");
				
				//Step2:Creating the html report
				extent=new ExtentReports();
				
				//Step3: attach the data to the html file
				extent.attachReporter(reporter);

	}
	
	
	
	@AfterSuite
	public void endReport() {
		// TODO Auto-generated method stub
		extent.flush();
	}
	
	@BeforeClass
	public void testcaseDetails() {
		
    test = extent.createTest(testname, testdescription);
    test.assignAuthor(testauthor);
    test.assignCategory(testcategory);
	}
	
	
	public int takesnap() throws IOException {
		int randomNumber=(int)(Math.random()*999999+99999);
		File source = getDriver().getScreenshotAs(OutputType.FILE);
		File destination=new File("./snaps/image"+randomNumber+".png");     //image1234.png   ////image4567.png
		FileUtils.copyFile(source, destination);
		return randomNumber;

	}
	
	
	
	public void reportStep(String status, String message) throws IOException {                              
		if(status.equalsIgnoreCase("Pass")) {                                              //5678
			test.pass(message,MediaEntityBuilder.createScreenCaptureFromPath(".././snaps/image"+takesnap()+".png").build());
		}

		else if(status.equalsIgnoreCase("Fail")) {
			test.fail(message);
		}
	}
	
	
	
	@BeforeMethod
	public void preCondition() {
		//driver=new ChromeDriver();
		setDriver();
		getDriver().manage().window().maximize();
		getDriver().get("http://leaftaps.com/opentaps/control/main");

	}
	
	@AfterMethod
	public void postCondition() {
		getDriver().close();

	}
	
	
	@DataProvider(name="fetchData")
	public  String[][] sendData() throws IOException {
		return ReadExcel.readData(filename);//EditLead
	}


}
