package testcase;

import java.io.IOException;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.BaseClass;
import pages.LoginPage;

public class TC_001_CreateLead extends BaseClass {
	
	
	@BeforeTest
	public void setValues() {
		filename="CreateLead";
		testname="Createlead";
		testauthor="Vineeth";
testdescription="CreateLead with multiple data";
testcategory="Sanity";
	}
	
	
	
	@Test(dataProvider ="fetchData")
	public void runCreateLead(String uName, String pWord,String cName, String fName, String lName) throws IOException {
		
          LoginPage lp=new LoginPage();
          lp.enterUsername(uName)
          .enterPassword(pWord)
          .clickLoginButton()
          .clickCrmsfaLink()
          .clickLeadsLink()
          .clickCreateLeadLink()
          .enterCompanyname(cName)
          .enterFirstname(fName)
          .enterLastname(lName)
          .clickCreateLeadButton()
          .verifyLead();
          
          
	}

}
