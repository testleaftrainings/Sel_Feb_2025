package pages;

import java.io.IOException;

import org.openqa.selenium.By;

import base.BaseClass;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.When;

public class LoginPage extends BaseClass{
	
	
	@Given("Enter the username as {string}")
	public LoginPage enterUsername(String uName) throws IOException {
		getDriver().findElement(By.id("username")).sendKeys(uName);
		reportStep("Pass", "username enterted sucessfully");
		return this;

	}
	@And("Enter the password as {string}")
   public LoginPage enterPassword(String pWord) {
		getDriver().findElement(By.id("password")).sendKeys(pWord);
       return this;
	}
@When("Click on the Login button")
   public WelcomePage clickLoginButton() {
	getDriver().findElement(By.className("decorativeSubmit")).click();
	   System.out.println("Login is created");
       return new WelcomePage();
	   //WelcomePage wp=new WelcomePage();
	   //return wp;
  }

}
