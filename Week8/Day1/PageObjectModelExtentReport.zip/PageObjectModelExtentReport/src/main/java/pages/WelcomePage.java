package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import base.BaseClass;
import io.cucumber.java.en.And;
import io.cucumber.java.en.But;
import io.cucumber.java.en.Then;

public class WelcomePage extends BaseClass {
	


@Then("It should navigate to the next page")
public void verifyLogin() {
	
System.out.println("Login successful");
}

@But("It should throw error message")
public void verifyfailureLogin() {
	// TODO Auto-generated method stub

}
	
@And("Click on the CRMSFA link")
   public MyHomePage clickCrmsfaLink() {
	getDriver().findElement(By.linkText("CRM/SFA")).click();
return new MyHomePage();
	}

}
