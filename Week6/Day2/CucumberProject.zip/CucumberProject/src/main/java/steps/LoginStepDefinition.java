package steps;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class LoginStepDefinition {
	public ChromeDriver driver;
	
	
	
		
	@And("Load the url")
	public void load_the_url() {
		driver.get("http://leaftaps.com/opentaps/control/main");
	}

	@And("Enter the username as {string}")
	public void enter_the_username_as_demosalesmanager(String username) {
		driver.findElement(By.id("username")).sendKeys(username);
	}
	
	
	@When("It should throw error message")
	public void it_should_throw_error_message() {
	  System.out.println("It throws error message");
	}
	
	
	@Given("Launch the browser")
	public void launchBrowser() {
		// TODO Auto-generated method stub
		driver=new ChromeDriver();
		driver.manage().window().maximize();
	}

	@And("Enter the password as crmsfa")
	public void enter_the_password_as_crmsfa() {
		driver.findElement(By.id("password")).sendKeys("crmsfa");
	}

	@When("Click on the Login button")
	public void click_on_the_login_button() {
		driver.findElement(By.className("decorativeSubmit")).click();
	}

	@Then("It should navigate to the next page")
	public void it_should_navigate_to_the_next_page() {
	    WebElement findElement = driver.findElement(By.xpath("//h2[text()='Welcome ']"));
	    String text = findElement.getText();
	    if (text.contains("Welcome")) {
			System.out.println("Login is succesful");
		}
	    
	    else {
			System.out.println("Login not successful");
		}
	    
	    
	}
}
