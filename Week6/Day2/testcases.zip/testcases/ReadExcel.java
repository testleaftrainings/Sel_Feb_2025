package testcases;

import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ReadExcel {
                                         //EditLead
	public static String[][] readData(String filename) throws IOException {
	
       //To open the workbook                     //EditLead
		XSSFWorkbook wb=new XSSFWorkbook("./Data/"+filename+".xlsx");
		
	    //	To open the worksheet
		XSSFSheet ws = wb.getSheetAt(0);
		
	    //To count the number of rows(Excluding header)
		int rowCount = ws.getLastRowNum();
		System.out.println("The row count is: "+rowCount);
		
		//To count the number of rows(including header)
		int physicalNumberOfRows = ws.getPhysicalNumberOfRows();
		System.out.println("Exact row count is: "+physicalNumberOfRows);
		
		//To count the column
		int columnCount = ws.getRow(1).getLastCellNum();
		System.out.println("Column Count is " +columnCount);
		
		//To retrieve a particular data
		  String row1Cell1Data = ws.getRow(1).getCell(1).getStringCellValue();
		  System.out.println("Data is: "+row1Cell1Data);
		
		  String[][] data=new String[rowCount][columnCount];
		
		//To retrieve the entire data
		    for (int i = 1; i <= rowCount; i++) {
			XSSFRow row = ws.getRow(i);
			for (int j = 0; j < columnCount ; j++) {
			String allData = row.getCell(j).getStringCellValue();
			//i=1 j=0
			System.out.println(allData);
			//data[0][0]=TestLeaf
			////data[0][1]=Vineeth
			//data[0][2]=Rajendran
			
			//data[1][0]=Qeagle
			//data[1][1]=Hari
			//data[1][2]=R
			data[i-1][j]=allData;
			}
		}
		    wb.close();
		    return data;
		    
	}

}
