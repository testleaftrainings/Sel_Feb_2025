package week4.day1;

public interface Rbi {
	
	//Guidelines
	//Unimplemented or Abstract method
	//100% Abstraction before Java 1.8
	
    public void setInterestRate();
	
	public void verifyKyc();

}
