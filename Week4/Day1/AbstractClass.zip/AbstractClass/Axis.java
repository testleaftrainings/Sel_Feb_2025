package week4.day1;

public abstract class Axis implements Rbi {
	
	
	public abstract void provideHouseLoan();
	
	public void provideGoldLoan() {
		System.out.println("1 Lakh");
	}
	
	}
